from django.apps import AppConfig


class SitioConfig(AppConfig):
    name = 'sitio'
